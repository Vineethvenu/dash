import 'package:flutter/material.dart';
import 'package:manappuram_hrms/features/add/controller/add_user_controller.dart';
import 'package:provider/provider.dart';
import 'app.dart';
import 'package:url_strategy/url_strategy.dart';

import 'features/home/controller/home_controller.dart';
import 'features/user_info/controller/user_info_controller.dart';
void main() {
  setPathUrlStrategy();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => HomeController()),
        ChangeNotifierProvider(create: (_) => UserInfoController()),
        ChangeNotifierProvider(create: (_) => AddUserController(),)
      ],
      child: const MyApp(),
    ),
  );
}

