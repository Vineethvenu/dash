import 'package:flutter/material.dart';
import 'package:manappuram_hrms/core/utils/config/styles/colors.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/helpers/routes/app_route_path.dart';
import '../../controller/home_controller.dart';

class CustomDrawer extends StatelessWidget {
  const CustomDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    final drawerProvider = Provider.of<HomeController>(context);

    return Container(
      width: drawerProvider.showIcons ? 220 : 60,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.blueGrey[800]!, Colors.blueGrey[900]!],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(5),
              children: [
                ...drawerProvider.drawerMenuItems.map((item) {
                  bool isSelected = drawerProvider.selectedItem == item['name'];
                  return GestureDetector(
                    onTap: () {
                      drawerProvider.setSelectedItem(item['name']!);
                      context.go(item['route']!);
                    },
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? Colors.blueGrey[700]
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black26,
                            blurRadius: 4,
                            offset: Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 12.0, horizontal: 8.0),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            drawerProvider.showIcons
                                ? Icon(
                                    item['icon'],
                                    size: 20,
                                    color: isSelected
                                        ? Colors.white
                                        : Colors.grey[300],
                                  )
                                : Expanded(
                                    child: Center(
                                      child: Icon(
                                        item['icon'],
                                        size: 20,
                                        color: isSelected
                                            ? Colors.white
                                            : Colors.grey[300],
                                      ),
                                    ),
                                  ),
                            SizedBox(width: drawerProvider.showIcons ? 16 : 0),
                            if (drawerProvider.showIcons)
                              Expanded(
                                child: Text(
                                  item['name']!,
                                  style: TextStyle(
                                    color: isSelected
                                        ? Colors.white
                                        : Colors.grey[300],
                                    fontWeight: isSelected
                                        ? FontWeight.bold
                                        : FontWeight.normal,
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ],
            ),
          ),
          // Fixed Logout Button
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: GestureDetector(
              onTap: () {
                _showLogoutDialog(context);
              },
              child: Container(
                margin: const EdgeInsets.symmetric(vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.blueGrey[700],
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 4,
                      offset: Offset(0, 2),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      vertical: 12.0, horizontal: 8.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      drawerProvider.showIcons
                          ? Icon(
                              Icons.logout_outlined,
                              size: 20,
                              color: Colors.white,
                            )
                          : Expanded(
                              child: Center(
                                child: Icon(
                                  Icons.logout_outlined,
                                  size: 20,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                      SizedBox(width: drawerProvider.showIcons ? 16 : 0),
                      if (drawerProvider.showIcons)
                        Expanded(
                          child: Text(
                            "Logout",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.normal,
                              fontSize: 16,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor:
              Colors.blueGrey[900], // Background color of the dialog
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15), // Rounded corners
          ),
          title: Text(
            "Logout",
            style: TextStyle(
              color: Colors.white, // Title text color
              fontWeight: FontWeight.bold,
              fontSize: 20, // Increased font size for the title
            ),
          ),
          content: Text(
            "Are you sure you want to logout?",
            style: TextStyle(
              color: Colors.white, // Content text color
              fontSize: 16, // Font size for the content
            ),
          ),
          actions: [
            Row(
              mainAxisAlignment:
                  MainAxisAlignment.spaceEvenly, // Space buttons evenly
              children: [
                // Cancel Button
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop(); // Close the dialog
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue, // Button background color
                    shape: RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(10), // Rounded corners
                    ),
                  ),
                  child: Text(
                    "Cancel",
                    style: TextStyle(
                      color: Colors.white, // Cancel button text color
                    ),
                  ),
                ),
                // Logout Button
                ElevatedButton(
                  onPressed: () {
                    // Handle logout logic here
                    Navigator.of(context).pop(); // Close the dialog
                    // Add your logout logic here
                    // Example: context.go('/login'); // Navigate to login screen
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red, // Button background color
                    shape: RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(10), // Rounded corners
                    ),
                  ),
                  child: Text(
                    "Logout",
                    style: TextStyle(
                      color: Colors.white, // Logout button text color
                    ),
                  ),
                ),
              ],
            ),
          ],
        );
      },
    );
  }
}
