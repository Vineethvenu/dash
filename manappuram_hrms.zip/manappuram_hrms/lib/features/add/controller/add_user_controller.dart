import 'package:flutter/cupertino.dart';

class AddUserController extends ChangeNotifier {
  var selectedDepartment = '';
  List<Map<String, dynamic>> filteredDepartments = [];

  var departments = [
    {"dept_name": "IT Department", "id": 1},
    {"dept_name": "IT Support", "id": 2},
    {"dept_name": "e-security", "id": 3},
    {"dept_name": "Non-IT", "id": 4}
  ];

  void filterDepartments(String query) {
    if (query.isEmpty) {
      filteredDepartments = departments;
      notifyListeners();
    } else {
      filteredDepartments = departments
          .where((element) => element['dept_name']
              .toString()
              .toLowerCase()
              .contains(query.toLowerCase()))
          .toList();
      notifyListeners();
    }
  }
}
