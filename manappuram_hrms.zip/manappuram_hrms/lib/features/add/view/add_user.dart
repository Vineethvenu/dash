import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/utils/config/styles/colors.dart';
import '../controller/add_user_controller.dart';

class AddUser extends StatefulWidget {
  const AddUser({super.key});

  @override
  State<AddUser> createState() => _AddUserState();
}

class _AddUserState extends State<AddUser> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _positionController = TextEditingController();
  final _departmentController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _dateOfBirthController = TextEditingController();
  final _addressController = TextEditingController();
  final _hireDateController = TextEditingController();
  final _salaryController = TextEditingController();
  final _statusController = TextEditingController();
  String? _gender;
  final _nationalityController = TextEditingController();
  final _skillsController = TextEditingController();
  final _projectsController = TextEditingController();
  final _emergencyContactNameController = TextEditingController();
  final _emergencyContactPhoneController = TextEditingController();
  final _linkedinProfileController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final addUserController = Provider.of<AddUserController>(context);
    addUserController.filteredDepartments = addUserController.departments;
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Container(
        padding: const EdgeInsets.all(8.0),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8.0),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 2,
              blurRadius: 5,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Form(
            key: _formKey,
            child: ListView(
              children: [
                Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                          flex: 5,
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              children: [
                                _customTextField(
                                  labelTxt: 'Name',
                                  hintTxt: 'Enter your name',
                                  controller: _nameController,
                                  keyboardType: TextInputType.text,
                                  labelTxtStyle:
                                      const TextStyle(color: Colors.black),
                                  hintTxtStyle:
                                      const TextStyle(color: Colors.black),
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter your name';
                                    }
                                    return null;
                                  },
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(10)),
                                  child: DropdownButtonFormField<String>(
                                    dropdownColor: Colors.white,
                                    validator: (value) => value == null
                                        ? 'Please fill in your gender'
                                        : null,
                                    value: addUserController
                                            .selectedDepartment.isNotEmpty
                                        ? addUserController.selectedDepartment
                                        : null,
                                    menuMaxHeight: 200,
                                    isExpanded: true,
                                    items: addUserController.filteredDepartments
                                        .map((element) {
                                      return DropdownMenuItem<String>(
                                        value: element['id'].toString(),
                                        child: Text(
                                            element['dept_name'].toString() ??
                                                ''),
                                      );
                                    }).toList(),
                                    decoration: InputDecoration(
                                      floatingLabelBehavior:
                                          FloatingLabelBehavior.never,
                                      filled: true,
                                      fillColor: const Color(0xfff5f5f5),
                                      hintStyle: const TextStyle(
                                        fontSize: 12,
                                        fontFamily: "poppinsRegular",
                                        color: Colors.black,
                                      ),
                                      contentPadding:
                                          const EdgeInsets.symmetric(
                                              vertical: 16.5, horizontal: 15),
                                      labelText: "Select Department",
                                      labelStyle: const TextStyle(
                                        fontSize: 16,
                                        fontFamily: "poppinsRegular",
                                        color: Colors.black,
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(10.0),
                                        borderSide: const BorderSide(
                                            color: Color(0xffd9d9d9)),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(10.0),
                                        borderSide: const BorderSide(
                                            color: Color(0xffd9d9d9)),
                                      ),
                                      errorBorder: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(10.0),
                                        borderSide:
                                            const BorderSide(color: Colors.red),
                                      ),
                                      border: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(10.0),
                                      ),
                                    ),
                                    onChanged: (value) {},
                                  ),
                                ),
                                ElevatedButton(
                                  onPressed: () {
                                    // Validate the form
                                    if (_formKey.currentState?.validate() ??
                                        false) {}
                                  },
                                  child: const Text('Submit'),
                                ),
                              ],
                            ),
                          )),
                      Expanded(
                          flex: 5,
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              children: [
                                _customTextField(
                                  labelTxt: 'Position',
                                  hintTxt: 'Enter your position',
                                  controller: _positionController,
                                  keyboardType: TextInputType.text,
                                  labelTxtStyle:
                                      const TextStyle(color: Colors.black),
                                  hintTxtStyle:
                                      const TextStyle(color: Colors.black),
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter your position';
                                    }
                                    return null;
                                  },
                                ),
                                DropdownButtonFormField2(
                                  items: addUserController.departments
                                      .map((element) {
                                    return DropdownMenuItem<String>(
                                      value: element['id'].toString(),
                                      child: Text(
                                          element['dept_name'].toString() ??
                                              ''),
                                    );
                                  }).toList(),
                                )
                              ],
                            ),
                          ))
                    ]),
              ],
            )),
      ),
    );
  }

  Widget _customTextField({
    required String labelTxt,
    required String hintTxt,
    required TextEditingController? controller,
    required TextInputType? keyboardType,
    required TextStyle? labelTxtStyle,
    required TextStyle? hintTxtStyle,
    String? Function(String?)? validator,
    bool obscureText = false,
    Widget? suffixIcon,
    bool readOnly = false,
  }) {
    return TextFormField(
      controller: controller,
      readOnly: readOnly,
      validator: validator,
      obscureText: obscureText,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        floatingLabelBehavior: FloatingLabelBehavior.never,
        filled: true,
        fillColor: const Color(0xffe0dbdb),
        suffixIcon: suffixIcon,
        hintText: hintTxt,
        hintStyle: hintTxtStyle,
        contentPadding: const EdgeInsets.all(12),
        labelText: labelTxt,
        labelStyle: labelTxtStyle,
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8.0),
          borderSide: const BorderSide(color: AppColor.borderColor),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8.0),
          borderSide: const BorderSide(color: AppColor.borderColor),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8.0),
          borderSide: const BorderSide(color: AppColor.errorBorder),
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8.0),
        ),
      ),
    );
  }
}
