import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';

import '../../../core/utils/config/styles/colors.dart';
import '../controller/user_info_controller.dart';

class UserInfo extends StatefulWidget {
  const UserInfo({super.key});

  @override
  _UserInfoState createState() => _UserInfoState();
}

class _UserInfoState extends State<UserInfo> {
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 3), () {
      setState(() {
        _isLoading = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final userInfoController = Provider.of<UserInfoController>(context);

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Container(
        padding: const EdgeInsets.all(8.0),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8.0),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 2,
              blurRadius: 5,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          children: [
            SizedBox(
              height: 80, // Adjust the height as needed
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: _customTextField(
                  labelTxt: 'Search',
                  hintTxt: 'Search',
                  controller: null,
                  keyboardType: TextInputType.text,
                  labelTxtStyle: const TextStyle(
                    color: Colors.black,
                    fontSize: 16,
                  ),
                  hintTxtStyle: const TextStyle(
                    color: Colors.grey,
                    fontSize: 16,
                  ),
                  onChanged: (value) {
                    userInfoController.updateSearchQuery(value);
                  },
                ),
              ),
            ),
            Expanded(
              child: _isLoading
                  ? _buildShimmerList()
                  : SingleChildScrollView(
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          children: [
                            // DataTable
                            SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: DataTable(
                                  decoration:  BoxDecoration(
                                    borderRadius:  BorderRadius.only(
                                      topLeft: Radius.circular(16.0),
                                      topRight: Radius.circular(16.0),
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(0.5),
                                        spreadRadius: 2,
                                        blurRadius: 5,
                                        offset: const Offset(0, 3),
                                      ),
                                    ],
                                    color: Colors.white,
                                  ),
                                  dividerThickness: 0.5,
                                  headingRowColor:
                                      MaterialStateProperty.all<Color>(
                                    const Color(0xFF072C56),
                                  ),
                                  headingTextStyle: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  columns: const [
                                    DataColumn(label: const Text('#')),
                                    DataColumn(label: const Text('Name')),
                                    DataColumn(label: const Text('Position')),
                                    DataColumn(label: const Text('Department')),
                                    DataColumn(label: const Text('Email')),
                                    DataColumn(label: const Text('Phone')),
                                    DataColumn(
                                        label: const Text('Date of Birth')),
                                    DataColumn(label: const Text('Address')),
                                    DataColumn(label: const Text('Hire Date')),
                                    DataColumn(
                                        label: const Text('Salary'),
                                        numeric: true),
                                    DataColumn(label: const Text('Status')),
                                    DataColumn(label: const Text('Edit')),
                                  ],
                                  rows: List<DataRow>.generate(
                                    userInfoController.rowsPerPage,
                                    (index) {
                                      final employeeIndex =
                                          userInfoController.currentPage *
                                                  userInfoController.rowsPerPage +
                                              index;
                                      if (employeeIndex >=
                                          userInfoController
                                              .filteredEmployees.length) {
                                        return DataRow(
                                            cells: List.generate(
                                                12,
                                                (index) => DataCell(
                                                    Text('')))); // Empty row
                                      }
                                      final employee = userInfoController
                                          .filteredEmployees[employeeIndex];
                                      return DataRow(color: index % 2 == 0
                                            ? MaterialStateProperty.all(
                                                AppColor.breadCramp)
                                            : MaterialStateProperty.all(
                                                Colors.white),

                                        cells: [
                                          DataCell(CustomDataCellText(
                                              text: '${employeeIndex + 1}')),
                                          DataCell(CustomDataCellText(
                                              text: employee['name'] ?? '')),
                                          DataCell(CustomDataCellText(
                                              text: employee['position'] ?? '')),
                                          DataCell(CustomDataCellText(
                                              text:
                                                  employee['department'] ?? '')),
                                          DataCell(CustomDataCellText(
                                              text: employee['email'] ?? '')),
                                          DataCell(CustomDataCellText(
                                              text: employee['phone'] ?? '')),
                                          DataCell(CustomDataCellText(
                                              text:
                                                  employee['dateOfBirth'] ?? '')),
                                          DataCell(CustomDataCellText(
                                              text: employee['address'] ?? '')),
                                          DataCell(CustomDataCellText(
                                              text: employee['hireDate'] ?? '')),
                                          DataCell(CustomDataCellText(
                                              text: employee['salary']
                                                      ?.toString() ??
                                                  '')),
                                          DataCell(CustomDataCellText(
                                              text: employee['status'] ?? '')),
                                          DataCell(
                                            Row(
                                              children: [
                                                IconButton(
                                                  icon: Icon(Icons.edit),
                                                  color: Colors.blue,
                                                  onPressed: () {
                                                    // Handle update action
                                                    // userInfoController
                                                    //     .updateEmployee(
                                                    //     employeeIndex,
                                                    //     employee);
                                                  },
                                                ),
                                                IconButton(
                                                  icon: Icon(Icons.delete),
                                                  color: Colors.red,
                                                  onPressed: () {
                                                    // Handle delete action
                                                    // userInfoController
                                                    //     .deleteEmployee(
                                                    //     employeeIndex);
                                                  },
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      );
                                    },
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
            ),
            // Fixed Pagination Controls
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: PaginationControls(
                currentPage: userInfoController.currentPage,
                totalPages: userInfoController.totalPages,
                onPageChanged: (page) {
                  userInfoController.updateCurrentPage(page);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
  Widget PaginationControls({
    required int currentPage,
    required int totalPages,
    required void Function(int) onPageChanged,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Flexible(
          child: DropdownButton<int>(
            value: currentPage + 1,
            items: List.generate(
              totalPages,
                  (index) => DropdownMenuItem<int>(
                value: index + 1,
                child: Text('Page ${ index + 1 }'),
              ),
            ),
            onChanged: (value) {
              if (value != null) {
                onPageChanged(value - 1);
              }
            },
            style: const TextStyle(
              color: Colors.black,
              fontSize: 16,
            ),
            dropdownColor: Colors.white,
            elevation: 8,
            underline: Container(
              height: 0,
            ),
            icon: const Icon(
              Icons.arrow_drop_down,
              color: Colors.grey,
            ),
            iconSize: 24,
            borderRadius: BorderRadius.circular(8.0),
            alignment: Alignment.centerLeft,
          ),
        ),
        Row(
          children: [
            IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: currentPage > 0 ? Colors.black : Colors.grey,
              ),
              onPressed: currentPage > 0
                  ? () {
                onPageChanged(currentPage - 1);
              }
                  : null,
            ),
            IconButton(
              icon: Icon(
                Icons.arrow_forward,
                color: currentPage < totalPages - 1 ? Colors.black : Colors.grey,
              ),
              onPressed: currentPage < totalPages - 1
                  ? () {
                onPageChanged(currentPage + 1);
              }
                  : null,
            ),
          ],
        ),
      ],
    );
  }



  Widget _customTextField({
    required String labelTxt,
    required String hintTxt,
    required TextEditingController? controller,
    required TextInputType? keyboardType,
    required TextStyle? labelTxtStyle,
    required TextStyle? hintTxtStyle,
    required void Function(String) onChanged,
    String? Function(String?)? validator,
    bool obscureText = false,
    IconButton? suffixIcon,
    bool readOnly = false,
  }) {
    return TextFormField(
      controller: controller,
      readOnly: readOnly,
      validator: validator,
      obscureText: obscureText,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        floatingLabelBehavior: FloatingLabelBehavior.never,
        filled: true,
        fillColor: const Color(0xfff5f5f5),
        suffixIcon: suffixIcon,
        hintText: hintTxt,
        hintStyle: hintTxtStyle,
        contentPadding: const EdgeInsets.all(12),
        labelText: labelTxt,
        labelStyle: labelTxtStyle,
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30.0),
          borderSide: const BorderSide(color: AppColor.borderColor),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30.0),
          borderSide: const BorderSide(color: AppColor.borderColor),
        ),
        errorBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: AppColor.errorBorder),
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
      ),
      onChanged: onChanged,
    );
  }

  Widget CustomDataCellText({required String text}) {
    return Text(
      text,
      style: const TextStyle(
        color: Colors.black,
        fontSize: 14,
      ),
    );
  }

  Widget textFileldTitle({required String title, required IconData icon}) {
    return Row(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Icon(
          icon,
          size: 20,
          color: AppColor.btnColor,
        ),
        Text(
          title,
          style: const TextStyle(
            fontSize: 14,
            color: AppColor.btnColor,
          ),
        ),
        const Spacer()
      ],
    );
  }

  Widget _buildShimmerList() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          Shimmer.fromColors(
            baseColor: Colors.grey.shade300,
            highlightColor: Colors.grey.shade100,
            child: Container(
              height: 80,
              color: Colors.white,
              margin: const EdgeInsets.only(bottom: 16.0),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: 25,
              itemBuilder: (context, index) {
                return Shimmer.fromColors(
                  baseColor: Colors.grey.shade300,
                  highlightColor: Colors.grey.shade100,
                  child: Container(
                    height: 20,
                    color: Colors.white,
                    margin: const EdgeInsets.symmetric(vertical: 4),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
