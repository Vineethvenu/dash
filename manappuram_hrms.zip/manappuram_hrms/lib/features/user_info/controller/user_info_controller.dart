import 'package:flutter/material.dart';

class UserInfoController extends ChangeNotifier {
  String searchQuery = '';
  int rowsPerPage = 10;
  int currentPage = 0;
  //data table2
  final List<Map<String, dynamic>> employeeDetails = [
    {
      'name': 'Bob Brown',
      'position': 'QA Engineer',
      'department': 'Quality Assurance',
      'email': 'bob.brown@example.com',
      'phone': '444-444-4444',
      'dateOfBirth': '1988-11-05',
      'address': '321 Pine St, Springfield, USA',
      'hireDate': '2018-09-20',
      'salary': 75000,
      'status': 'Active',
      'gender': 'Male',
      'nationality': 'American',
      'skills': ['Selenium', 'JUnit', 'Test Automation'],
      'projects': ['Project G', 'Project H'],
      'emergencyContact': {
        'name': 'Alice Brown',
        'phone': '111-222-3333',
      },
      'linkedinProfile': 'https://www.linkedin.com/in/bobbrown',
    },
    {
      'name': 'Bob Brown',
      'position': 'QA Engineer',
      'department': 'Quality Assurance',
      'email': 'bob.brown@example.com',
      'phone': '444-444-4444',
      'dateOfBirth': '1988-11-05',
      'address': '321 Pine St, Springfield, USA',
      'hireDate': '2018-09-20',
      'salary': 75000,
      'status': 'Active',
      'gender': 'Male',
      'nationality': 'American',
      'skills': ['Selenium', 'JUnit', 'Test Automation'],
      'projects': ['Project G', 'Project H'],
      'emergencyContact': {
        'name': 'Alice Brown',
        'phone': '111-222-3333',
      },
      'linkedinProfile': 'https://www.linkedin.com/in/bobbrown',
    },
    {
      'name': 'Bob Brown',
      'position': 'QA Engineer',
      'department': 'Quality Assurance',
      'email': 'bob.brown@example.com',
      'phone': '444-444-4444',
      'dateOfBirth': '1988-11-05',
      'address': '321 Pine St, Springfield, USA',
      'hireDate': '2018-09-20',
      'salary': 75000,
      'status': 'Active',
      'gender': 'Male',
      'nationality': 'American',
      'skills': ['Selenium', 'JUnit', 'Test Automation'],
      'projects': ['Project G', 'Project H'],
      'emergencyContact': {
        'name': 'Alice Brown',
        'phone': '111-222-3333',
      },
      'linkedinProfile': 'https://www.linkedin.com/in/bobbrown',
    },
    {
      'name': 'Bob Brown',
      'position': 'QA Engineer',
      'department': 'Quality Assurance',
      'email': 'bob.brown@example.com',
      'phone': '444-444-4444',
      'dateOfBirth': '1988-11-05',
      'address': '321 Pine St, Springfield, USA',
      'hireDate': '2018-09-20',
      'salary': 75000,
      'status': 'Active',
      'gender': 'Male',
      'nationality': 'American',
      'skills': ['Selenium', 'JUnit', 'Test Automation'],
      'projects': ['Project G', 'Project H'],
      'emergencyContact': {
        'name': 'Alice Brown',
        'phone': '111-222-3333',
      },
      'linkedinProfile': 'https://www.linkedin.com/in/bobbrown',
    },
    {
      'name': 'Bob Brown',
      'position': 'QA Engineer',
      'department': 'Quality Assurance',
      'email': 'bob.brown@example.com',
      'phone': '444-444-4444',
      'dateOfBirth': '1988-11-05',
      'address': '321 Pine St, Springfield, USA',
      'hireDate': '2018-09-20',
      'salary': 75000,
      'status': 'Active',
      'gender': 'Male',
      'nationality': 'American',
      'skills': ['Selenium', 'JUnit', 'Test Automation'],
      'projects': ['Project G', 'Project H'],
      'emergencyContact': {
        'name': 'Alice Brown',
        'phone': '111-222-3333',
      },
      'linkedinProfile': 'https://www.linkedin.com/in/bobbrown',
    },
    {
      'name': 'Bob Brown',
      'position': 'QA Engineer',
      'department': 'Quality Assurance',
      'email': 'bob.brown@example.com',
      'phone': '444-444-4444',
      'dateOfBirth': '1988-11-05',
      'address': '321 Pine St, Springfield, USA',
      'hireDate': '2018-09-20',
      'salary': 75000,
      'status': 'Active',
      'gender': 'Male',
      'nationality': 'American',
      'skills': ['Selenium', 'JUnit', 'Test Automation'],
      'projects': ['Project G', 'Project H'],
      'emergencyContact': {
        'name': 'Alice Brown',
        'phone': '111-222-3333',
      },
      'linkedinProfile': 'https://www.linkedin.com/in/bobbrown',
    },
    {
      'name': 'Bob Brown',
      'position': 'QA Engineer',
      'department': 'Quality Assurance',
      'email': 'bob.brown@example.com',
      'phone': '444-444-4444',
      'dateOfBirth': '1988-11-05',
      'address': '321 Pine St, Springfield, USA',
      'hireDate': '2018-09-20',
      'salary': 75000,
      'status': 'Active',
      'gender': 'Male',
      'nationality': 'American',
      'skills': ['Selenium', 'JUnit', 'Test Automation'],
      'projects': ['Project G', 'Project H'],
      'emergencyContact': {
        'name': 'Alice Brown',
        'phone': '111-222-3333',
      },
      'linkedinProfile': 'https://www.linkedin.com/in/bobbrown',
    },
    {
      'name': 'Bob Brown',
      'position': 'QA Engineer',
      'department': 'Quality Assurance',
      'email': 'bob.brown@example.com',
      'phone': '444-444-4444',
      'dateOfBirth': '1988-11-05',
      'address': '321 Pine St, Springfield, USA',
      'hireDate': '2018-09-20',
      'salary': 75000,
      'status': 'Active',
      'gender': 'Male',
      'nationality': 'American',
      'skills': ['Selenium', 'JUnit', 'Test Automation'],
      'projects': ['Project G', 'Project H'],
      'emergencyContact': {
        'name': 'Alice Brown',
        'phone': '111-222-3333',
      },
      'linkedinProfile': 'https://www.linkedin.com/in/bobbrown',
    },
    {
      'name': 'Bob Brown',
      'position': 'QA Engineer',
      'department': 'Quality Assurance',
      'email': 'bob.brown@example.com',
      'phone': '444-444-4444',
      'dateOfBirth': '1988-11-05',
      'address': '321 Pine St, Springfield, USA',
      'hireDate': '2018-09-20',
      'salary': 75000,
      'status': 'Active',
      'gender': 'Male',
      'nationality': 'American',
      'skills': ['Selenium', 'JUnit', 'Test Automation'],
      'projects': ['Project G', 'Project H'],
      'emergencyContact': {
        'name': 'Alice Brown',
        'phone': '111-222-3333',
      },
      'linkedinProfile': 'https://www.linkedin.com/in/bobbrown',
    },
    {
      'name': 'Bob Brown',
      'position': 'QA Engineer',
      'department': 'Quality Assurance',
      'email': 'bob.brown@example.com',
      'phone': '444-444-4444',
      'dateOfBirth': '1988-11-05',
      'address': '321 Pine St, Springfield, USA',
      'hireDate': '2018-09-20',
      'salary': 75000,
      'status': 'Active',
      'gender': 'Male',
      'nationality': 'American',
      'skills': ['Selenium', 'JUnit', 'Test Automation'],
      'projects': ['Project G', 'Project H'],
      'emergencyContact': {
        'name': 'Alice Brown',
        'phone': '111-222-3333',
      },
      'linkedinProfile': 'https://www.linkedin.com/in/bobbrown',
    },
    {
      'name': 'Bob Brown',
      'position': 'QA Engineer',
      'department': 'Quality Assurance',
      'email': 'bob.brown@example.com',
      'phone': '444-444-4444',
      'dateOfBirth': '1988-11-05',
      'address': '321 Pine St, Springfield, USA',
      'hireDate': '2018-09-20',
      'salary': 75000,
      'status': 'Active',
      'gender': 'Male',
      'nationality': 'American',
      'skills': ['Selenium', 'JUnit', 'Test Automation'],
      'projects': ['Project G', 'Project H'],
      'emergencyContact': {
        'name': 'Alice Brown',
        'phone': '111-222-3333',
      },
      'linkedinProfile': 'https://www.linkedin.com/in/bobbrown',
    },
    {
      'name': 'Bob Brown',
      'position': 'QA Engineer',
      'department': 'Quality Assurance',
      'email': 'bob.brown@example.com',
      'phone': '444-444-4444',
      'dateOfBirth': '1988-11-05',
      'address': '321 Pine St, Springfield, USA',
      'hireDate': '2018-09-20',
      'salary': 75000,
      'status': 'Active',
      'gender': 'Male',
      'nationality': 'American',
      'skills': ['Selenium', 'JUnit', 'Test Automation'],
      'projects': ['Project G', 'Project H'],
      'emergencyContact': {
        'name': 'Alice Brown',
        'phone': '111-222-3333',
      },
      'linkedinProfile': 'https://www.linkedin.com/in/bobbrown',
    },
    {
      'name': 'Bob Brown',
      'position': 'QA Engineer',
      'department': 'Quality Assurance',
      'email': 'bob.brown@example.com',
      'phone': '444-444-4444',
      'dateOfBirth': '1988-11-05',
      'address': '321 Pine St, Springfield, USA',
      'hireDate': '2018-09-20',
      'salary': 75000,
      'status': 'Active',
      'gender': 'Male',
      'nationality': 'American',
      'skills': ['Selenium', 'JUnit', 'Test Automation'],
      'projects': ['Project G', 'Project H'],
      'emergencyContact': {
        'name': 'Alice Brown',
        'phone': '111-222-3333',
      },
      'linkedinProfile': 'https://www.linkedin.com/in/bobbrown',
    },
    {
      'name': 'Bob Brown',
      'position': 'QA Engineer',
      'department': 'Quality Assurance',
      'email': 'bob.brown@example.com',
      'phone': '444-444-4444',
      'dateOfBirth': '1988-11-05',
      'address': '321 Pine St, Springfield, USA',
      'hireDate': '2018-09-20',
      'salary': 75000,
      'status': 'Active',
      'gender': 'Male',
      'nationality': 'American',
      'skills': ['Selenium', 'JUnit', 'Test Automation'],
      'projects': ['Project G', 'Project H'],
      'emergencyContact': {
        'name': 'Alice Brown',
        'phone': '111-222-3333',
      },
      'linkedinProfile': 'https://www.linkedin.com/in/bobbrown',
    },
    {
      'name': 'Bob Brown',
      'position': 'QA Engineer',
      'department': 'Quality Assurance',
      'email': 'bob.brown@example.com',
      'phone': '444-444-4444',
      'dateOfBirth': '1988-11-05',
      'address': '321 Pine St, Springfield, USA',
      'hireDate': '2018-09-20',
      'salary': 75000,
      'status': 'Active',
      'gender': 'Male',
      'nationality': 'American',
      'skills': ['Selenium', 'JUnit', 'Test Automation'],
      'projects': ['Project G', 'Project H'],
      'emergencyContact': {
        'name': 'Alice Brown',
        'phone': '111-222-3333',
      },
      'linkedinProfile': 'https://www.linkedin.com/in/bobbrown',
    },
    {
      'name': 'Bob Brown',
      'position': 'QA Engineer',
      'department': 'Quality Assurance',
      'email': 'bob.brown@example.com',
      'phone': '444-444-4444',
      'dateOfBirth': '1988-11-05',
      'address': '321 Pine St, Springfield, USA',
      'hireDate': '2018-09-20',
      'salary': 75000,
      'status': 'Active',
      'gender': 'Male',
      'nationality': 'American',
      'skills': ['Selenium', 'JUnit', 'Test Automation'],
      'projects': ['Project G', 'Project H'],
      'emergencyContact': {
        'name': 'Alice Brown',
        'phone': '111-222-3333',
      },
      'linkedinProfile': 'https://www.linkedin.com/in/bobbrown',
    },
    {
      'name': 'Bob Brown',
      'position': 'QA Engineer',
      'department': 'Quality Assurance',
      'email': 'bob.brown@example.com',
      'phone': '444-444-4444',
      'dateOfBirth': '1988-11-05',
      'address': '321 Pine St, Springfield, USA',
      'hireDate': '2018-09-20',
      'salary': 75000,
      'status': 'Active',
      'gender': 'Male',
      'nationality': 'American',
      'skills': ['Selenium', 'JUnit', 'Test Automation'],
      'projects': ['Project G', 'Project H'],
      'emergencyContact': {
        'name': 'Alice Brown',
        'phone': '111-222-3333',
      },
      'linkedinProfile': 'https://www.linkedin.com/in/bobbrown',
    },
    {
      'name': 'anu',
      'position': 'QA Engineer',
      'department': 'Quality Assurance',
      'email': 'bob.brown@example.com',
      'phone': '444-444-4444',
      'dateOfBirth': '1988-11-05',
      'address': '321 Pine St, Springfield, USA',
      'hireDate': '2018-09-20',
      'salary': 75000,
      'status': 'Active',
      'gender': 'Male',
      'nationality': 'American',
      'skills': ['Selenium', 'JUnit', 'Test Automation'],
      'projects': ['Project G', 'Project H'],
      'emergencyContact': {
        'name': 'Alice Brown',
        'phone': '111-222-3333',
      },
      'linkedinProfile': 'https://www.linkedin.com/in/bobbrown',
    }
  ];
  // Get filtered employees based on the search query
  List<Map<String, dynamic>> get filteredEmployees {
    return employeeDetails.where((employee) {
      return employee['name']
              .toString()
              .toLowerCase()
              .contains(searchQuery.toLowerCase()) ||
          employee['position']
              .toString()
              .toLowerCase()
              .contains(searchQuery.toLowerCase()) ||
          employee['department']
              .toString()
              .toLowerCase()
              .contains(searchQuery.toLowerCase()) ||
          employee['email']
              .toString()
              .toLowerCase()
              .contains(searchQuery.toLowerCase()) ||
          employee['phone']
              .toString()
              .toLowerCase()
              .contains(searchQuery.toLowerCase());
    }).toList();
  }

  // Calculate the total number of pages
  int get totalPages {
    return (filteredEmployees.length / rowsPerPage).ceil();
  }

  // Update the search query and notify listeners
  void updateSearchQuery(String query) {
    searchQuery = query;
    notifyListeners();
  }

  // Update the current page and notify listeners
  void updateCurrentPage(int page) {
    currentPage = page;
    notifyListeners();
  }

  int _selectedEmployeeIndex = -1;

  int get selectedEmployeeIndex => _selectedEmployeeIndex;

  void selectEmployee(int index) {
    _selectedEmployeeIndex = index;
    notifyListeners();
  }
}
