// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import '../home/controller/home_controller.dart';
//
// class ProductView extends StatefulWidget {
//   const ProductView({super.key});
//
//   @override
//   _ProductViewState createState() => _ProductViewState();
// }
//
// class _ProductViewState extends State<ProductView> {
//   String searchQuery = '';
//   int rowsPerPage = 10; // Number of rows per page
//   int currentPage = 0;
//
//   @override
//   Widget build(BuildContext context) {
//     final homeController = Provider.of<HomeController>(context);
//     final employeeDetails = homeController.employeeDetails;
//
//     // Filter employee details based on search query
//     final filteredEmployees = employeeDetails.where((employee) {
//       return employee['name']
//           .toString()
//           .toLowerCase()
//           .contains(searchQuery.toLowerCase()) ||
//           employee['position']
//               .toString()
//               .toLowerCase()
//               .contains(searchQuery.toLowerCase()) ||
//           employee['department']
//               .toString()
//               .toLowerCase()
//               .contains(searchQuery.toLowerCase()) ||
//           employee['email']
//               .toString()
//               .toLowerCase()
//               .contains(searchQuery.toLowerCase()) ||
//           employee['phone']
//               .toString()
//               .toLowerCase()
//               .contains(searchQuery.toLowerCase());
//     }).toList();
//
//     // Calculate the total number of pages
//     final totalPages = (filteredEmployees.length / rowsPerPage).ceil();
//
//     return Padding(
//       padding: const EdgeInsets.all(16.0),
//       child: Card(
//         color: Colors.white,
//         elevation: 8,
//         shape: RoundedRectangleBorder(
//           borderRadius: BorderRadius.circular(16.0),
//         ),
//         child: Padding(
//           padding: const EdgeInsets.all(16.0),
//           child: SingleChildScrollView(
//             // Wrap the entire content in a SingleChildScrollView
//             child: Column(
//               children: [
//                 // Search Bar
//                 TextField(
//                   decoration: InputDecoration(
//                     labelText: 'Search',
//                     border: OutlineInputBorder(),
//                     prefixIcon: Icon(Icons.search),
//                   ),
//                   onChanged: (value) {
//                     setState(() {
//                       searchQuery = value;
//                     });
//                   },
//                 ),
//                 SizedBox(height: 16.0),
//                 // DataTable
//                 SingleChildScrollView(
//                   scrollDirection: Axis.horizontal,
//                   child: DataTable(
//                     headingRowColor: MaterialStateProperty.all<Color>(
//                       const Color(0xFF072C56),
//                     ),
//                     headingTextStyle: const TextStyle(
//                       color: Colors.white,
//                       fontSize: 16,
//                       fontWeight: FontWeight.bold,
//                     ),
//                     columns: [
//                       DataColumn(label: const Text('Name')),
//                       DataColumn(label: const Text('Position')),
//                       DataColumn(label: const Text('Department')),
//                       DataColumn(label: const Text('Email')),
//                       DataColumn(label: const Text('Phone')),
//                       DataColumn(label: const Text('Date of Birth')),
//                       DataColumn(label: const Text('Address')),
//                       DataColumn(label: const Text('Hire Date')),
//                       DataColumn(label: const Text('Salary'), numeric: true),
//                       DataColumn(label: const Text('Status')),
//                     ],
//                     rows: List<DataRow>.generate(
//                       (currentPage + 1) * rowsPerPage > filteredEmployees.length
//                           ? filteredEmployees.length - currentPage * rowsPerPage
//                           : rowsPerPage,
//                           (index) {
//                         final employee = filteredEmployees[
//                         currentPage * rowsPerPage + index];
//                         return DataRow(
//                           color: index % 2 == 0
//                               ? MaterialStateProperty.all(Colors.grey[200])
//                               : MaterialStateProperty.all(Colors.white),
//                           cells: [
//                             DataCell(CustomDataCellText(
//                                 text: employee['name'] ?? '')),
//                             DataCell(CustomDataCellText(
//                                 text: employee['position'] ?? '')),
//                             DataCell(CustomDataCellText(
//                                 text: employee['department'] ?? '')),
//                             DataCell(CustomDataCellText(
//                                 text: employee['email'] ?? '')),
//                             DataCell(CustomDataCellText(
//                                 text: employee['phone'] ?? '')),
//                             DataCell(CustomDataCellText(
//                                 text: employee['dateOfBirth'] ?? '')),
//                             DataCell(CustomDataCellText(
//                                 text: employee['address'] ?? '')),
//                             DataCell(CustomDataCellText(
//                                 text: employee['hireDate'] ?? '')),
//                             DataCell(CustomDataCellText(
//                                 text: employee['salary']?.toString() ?? '')),
//                             DataCell(CustomDataCellText(
//                                 text: employee['status'] ?? '')),
//                           ],
//                         );
//                       },
//                     ),
//                   ),
//                 ),
//                 // Pagination Controls
//                 SizedBox(height: 16.0),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                   children: [
//                     Text('Page ${currentPage + 1} of $totalPages'),
//                     Row(
//                       children: [
//                         IconButton(
//                           icon: Icon(Icons.arrow_back),
//                           onPressed: currentPage > 0
//                               ? () {
//                             setState(() {
//                               currentPage--;
//                             });
//                           }
//                               : null,
//                         ),
//                         IconButton(
//                           icon: Icon(Icons.arrow_forward),
//                           onPressed: currentPage < totalPages - 1
//                               ? () {
//                             setState(() {
//                               currentPage++;
//                             });
//                           }
//                               : null,
//                         ),
//                       ],
//                     ),
//                   ],
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget CustomDataCellText({required String text}) {
//     return Text(
//       text,
//       style: const TextStyle(
//         color: Colors.black,
//         fontSize: 14,
//       ),
//     );
//   }
// }
