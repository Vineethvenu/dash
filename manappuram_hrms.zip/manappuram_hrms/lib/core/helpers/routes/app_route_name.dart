class RoutesName {
  static const String dashboard = 'dashboard';
  static const String productView = 'productView';
  static const String productAdd = 'productAdd';
  static const String productUpdate = 'productUpdate';
  static const String productDelete = 'productDelete';
}