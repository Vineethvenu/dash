class RoutesPath {
  static const String dashboard = '/dashboard';
  static const String productView = '/dashboard/view';
  static const String productAdd = '/dashboard/add';
  static const String productUpdate = '/dashboard/update';
  static const String productDelete = '/dashboard/delete';
}
