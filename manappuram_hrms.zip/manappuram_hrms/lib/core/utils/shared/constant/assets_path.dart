class AssetsPath {
  // main pathes
  static const String images = 'assets/images/';

  // images pathes
  static const String appLogo = '${images}app_logo.png';
}