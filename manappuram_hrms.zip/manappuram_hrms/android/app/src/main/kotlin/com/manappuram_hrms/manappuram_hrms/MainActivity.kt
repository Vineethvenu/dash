package com.manappuram_hrms.manappuram_hrms

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
